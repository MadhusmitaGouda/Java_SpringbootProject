package com.management.services;

import java.util.List;

import com.management.domains.Student;



public interface MyServices {
	
	public void insert(Student s);
	public void update(Student s);
	public void delete(Integer id);
	public Student getOne(Integer id);
	public List<Student> showData();

}
