package com.management.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.management.domains.Student;
import com.management.repository.MyRepository;

@Service
public class MyServiceImpl implements MyServices{

	@Autowired
	public MyRepository repo;
	
	public MyServiceImpl() {
		System.out.println("Service...");
	}
	
	@Override
	public void insert(Student s) {
		repo.save(s);
		
	}

	@Override
	public void update(Student s) {
		repo.save(s);
		
	}

	@Override
	public void delete(Integer id) {
		repo.deleteById(id);
		
	}

	@Override
	public Student getOne(Integer id) {
		Student st=repo.findById(id).get();
		return st;
	}

	@Override
	public List<Student> showData() {
		List<Student> stu=repo.findAll();
		return stu;
	}
	
	
}


