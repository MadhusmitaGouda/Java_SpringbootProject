package com.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.management.domains.Student;
import com.management.services.MyServices;
@Controller
public class MyController {
	
	@Autowired
	public MyServices serv;

	public MyController() {
		System.out.println("Controller...");
	}

	@GetMapping("/")
	public String insertdata() {
	return "Frontpage";
	}
	@PostMapping("/insrt")
	public String inserti(@ModelAttribute("key")Student s) {
		serv.insert(s);
	return "redirect:dis";
	}

	@GetMapping("/dis")
	public String show(@ModelAttribute("key")Student s,Model m) {
	 List<Student> std=serv.showData();
	 m.addAttribute("stdnt", std);
	return "Displaypage";
	}
	
	@GetMapping("/upda")
	public String updt(@RequestParam("id")Integer id, Model m) {
		Student stt=serv.getOne(id);
		m.addAttribute("stdent", stt);
		return "Updatepage";
		
		
	}
	
	@PostMapping("/updated")
	public String updatess(@ModelAttribute("key")Student s) {
		serv.update(s);
		return "redirect:dis";
	}
	
	@GetMapping("/delete")
	public String delte(@RequestParam("id")Integer id) {
		serv.delete(id);
		return "redirect:dis";
	}


}
